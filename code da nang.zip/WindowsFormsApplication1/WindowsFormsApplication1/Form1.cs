﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using Microsoft.Win32;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
            Load += Form1_Load; 
        }
        private void Center_Text()
        {
            Graphics g = this.CreateGraphics();
            Double startingPoint = (this.Width / 2) - (g.MeasureString(this.Text.Trim(), this.Font).Width / 2);
            Double widthOfASpace = g.MeasureString(" ", this.Font).Width;
            String tmp = " ";
            Double tmpWidth = 0;
            while ((tmpWidth + widthOfASpace) < startingPoint)
            {
                tmp += " ";
                tmpWidth += widthOfASpace;
            }
            this.Text = tmp + this.Text.Trim();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.Focus();
            Center_Text();
            rk.SetValue("WindowsFormsApplication1.exe", Application.ExecutablePath.ToString());
            timer1.Start();
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //if (textBox1.Text == "")
            //{
            //    MessageBox.Show("BẠN VUI LÒNG NHẬP TÊN BÀI HÁT Ở ĐÂY", "THÔNG BÁO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            //    textBox1.Focus();
            //    textBox1.Text = "";
            //}
            //if (textBox1.Text != "" && radioButton1.Checked == false || textBox1.Text != ""  && radioButton2.Checked == false || textBox1.Text != "" && radioButton3.Checked == false || textBox1.Text != "" && radioButton4.Checked == false)
            //{
            //    MessageBox.Show("BẠN CHƯA CHỌN NGUỒN Ở DƯỚI", "THÔNG BÁO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            //}

            //if (textBox1.Text == "" && radioButton1.Checked== true)
            //{
            //    MessageBox.Show("BẠN VUI LÒNG NHẬP TÊN BÀI HÁT Ở ĐÂY", "THÔNG BÁO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            //    textBox1.Focus();
            //    textBox1.Text = "";
            //}
            //if (textBox1.Text != "" && radioButton1.Checked == true)
            //{
            //    Process.Start("http://mp3.zing.vn/tim-kiem/bai-hat.html?q=" + textBox1.Text);
            // }


            //if (textBox1.Text == "" && radioButton2.Checked == true)
            //{
            //    textBox1.Text = "BẠN VUI LÒNG NHẬP TÊN BÀI HÁT Ở ĐÂY";
            //}
            //if(textBox1.Text == "" && radioButton3.Checked == true)
            //{
            //    textBox1.Text = "BẠN VUI LÒNG NHẬP TÊN BÀI HÁT Ở ĐÂY";
            //}
            //if(textBox1.Text == "" && radioButton4.Checked == true)
            //{
            //    textBox1.Text = "BẠN VUI LÒNG NHẬP TÊN BÀI HÁT Ở ĐÂY";
            //}

        }

        private void textBox1_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            radioButton1.Checked = radioButton2.Checked = radioButton3.Checked = radioButton4.Checked = false;
        }


        //private void textBox1_TextChanged(object sender, EventArgs e)
        //{

        //}

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton4.Checked == true)
            {
                textBox2.Visible = true;
                textBox2.Focus();
            }
            else
            {
                textBox2.Visible = false;
                textBox2.Text = "";
            }
            if (textBox1.Text == "" && radioButton4.Checked == true)
            {
                MessageBox.Show("BẠN VUI LÒNG NHẬP TÊN BÀI HÁT Ở ĐÂY", "THÔNG BÁO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox1.Focus();
                textBox1.Text = "";
                radioButton4.Checked = false;
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (textBox1.Text == "" && radioButton1.Checked == true)
            {
                MessageBox.Show("BẠN VUI LÒNG NHẬP TÊN BÀI HÁT Ở ĐÂY", "THÔNG BÁO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox1.Focus();
                textBox1.Text = "";
                radioButton1.Checked = false;
            }
            if (textBox1.Text != "" && radioButton1.Checked == true)
            {
                Process.Start("http://mp3.zing.vn/tim-kiem/bai-hat.html?q=" + textBox1.Text);
            }
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            if (textBox1.Text == "" && radioButton3.Checked == true)
            {
                MessageBox.Show("BẠN VUI LÒNG NHẬP TÊN BÀI HÁT Ở ĐÂY", "THÔNG BÁO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                radioButton3.Checked = false;
                textBox1.Focus();
                textBox1.Text = "";
            }
            if (textBox1.Text != "" && radioButton3.Checked == true)
            {
                Process.Start("http://www.nhaccuatui.com/tim-kiem?q=" + textBox1.Text);
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (textBox1.Text == "" && radioButton2.Checked == true)
            {
                MessageBox.Show("BẠN VUI LÒNG NHẬP TÊN BÀI HÁT Ở ĐÂY", "THÔNG BÁO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                radioButton2.Checked = false;
                textBox1.Focus();
                textBox1.Text = "";
            }
            if (textBox1.Text != "" && radioButton2.Checked == true)
            {
                Process.Start("http://search.chiasenhac.vn/search.php?s=" + textBox1.Text);
            }
        }

        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (textBox2.Text == "")
                {
                    MessageBox.Show("BẠN VUI LÒNG NHẬP NGUỒN TÌM KIẾM Ở ĐÂY", "THÔNG BÁO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    textBox2.Focus();
                    textBox2.Text = "";
                    
                }
                if (textBox2.Text != "")
                {
                    Process.Start("https://www.google.com.vn/search?q=" + " " + textBox1.Text + " " + "site: " + textBox2.Text);
                }
            }

        }

        //private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        //{

        //}

        //private void textBox2_TextChanged(object sender, EventArgs e)
        //{

        //}

        //private void tabPage2_Click(object sender, EventArgs e)
        //{

        //}

        private void radioButton7_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void tabPage2_Click(object sender, EventArgs e)
        {
            textBox3.Focus();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            textBox1.Focus();
        }

        private void radioButton8_CheckedChanged(object sender, EventArgs e)
        {
            if (textBox3.Text == "" && radioButton8.Checked == true)
            {
                MessageBox.Show("BẠN VUI LÒNG NHẬP PHIM Ở ĐÂY!!!", "THÔNG BÁO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox3.Focus();
                textBox3.Text = "";
                radioButton8.Checked = false;
            }
            if (textBox3.Text != "" && radioButton8.Checked == true)
            {
                Process.Start("https://www.youtube.com/results?search_query=" + textBox3.Text);
            }
        }

        private void radioButton7_CheckedChanged_1(object sender, EventArgs e)
        {
            if (textBox3.Text == "" && radioButton7.Checked == true)
            {
                MessageBox.Show("BẠN VUI LÒNG NHẬP PHIM Ở ĐÂY!!!", "THÔNG BÁO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox3.Focus();
                textBox3.Text = "";
                radioButton7.Checked = false;
            }
            if (textBox3.Text != "" && radioButton7.Checked == true)
            {
                Process.Start("http://hdonline.vn/tim-kiem/" + textBox3.Text);
            }
        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
            if (textBox3.Text == "" && radioButton6.Checked == true)
            {
                MessageBox.Show("BẠN VUI LÒNG NHẬP PHIM Ở ĐÂY!!!", "THÔNG BÁO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox3.Focus();
                textBox3.Text = "";
                radioButton6.Checked = false;
            }
            if (textBox3.Text != "" && radioButton6.Checked == true)
            {
                Process.Start("http://bomtan.org/full-hd/" + textBox3.Text);
            }
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton5.Checked == true)
            {
                textBox4.Visible = true;
                textBox4.Focus();
            }
            else
            {
                textBox4.Visible = false;
                textBox4.Text = "";
            }
            if (textBox3.Text == "" && radioButton5.Checked == true)
            {
                MessageBox.Show("BẠN VUI LÒNG NHẬP PHIM Ở ĐÂY", "THÔNG BÁO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox3.Focus();
                textBox3.Text = "";
                radioButton5.Checked = false;
            }
        }

        private void textBox4_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (textBox4.Text == "")
                {
                    MessageBox.Show("BẠN VUI LÒNG NHẬP NGUỒN TÌM KIẾM Ở ĐÂY", "THÔNG BÁO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    textBox4.Focus();
                    textBox4.Text = "";

                }
                if (textBox4.Text != "")
                {
                    Process.Start("https://www.google.com.vn/search?q=" + " " + textBox3.Text + " " + "site: " + textBox4.Text);
                }
            }
        }

        private void textBox3_Click(object sender, EventArgs e)
        {
            textBox3.Text = "";
            radioButton5.Checked = radioButton6.Checked = radioButton7.Checked = radioButton8.Checked = radioButton9.Checked = false;
        }

        private void radioButton9_CheckedChanged(object sender, EventArgs e)
        {
            if (textBox3.Text == "" && radioButton6.Checked == true)
            {
                MessageBox.Show("BẠN VUI LÒNG NHẬP PHIM Ở ĐÂY!!!", "THÔNG BÁO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox3.Focus();
                textBox3.Text = "";
                radioButton9.Checked = false;
            }
            if (textBox3.Text != "" && radioButton9.Checked == true)
            {
                Process.Start("http://anime47.com/tim-nang-cao/?keyword=" + textBox3.Text);
            }
        }

        //private void textBox3_KeyDown(object sender, KeyEventArgs e)
        //{
        //    if (e.KeyCode == Keys.Enter)
        //    {
        //        if (textBox3.Text == "")
        //        {
        //            MessageBox.Show("BẠN VUI LÒNG NHẬP NGUỒN TÌM KIẾM Ở ĐÂY", "THÔNG BÁO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        //            textBox3.Focus();
        //            textBox3.Text = "";

        //        }
        //        if (textBox3.Text != "")
        //        {
        //            Process.Start("https://www.google.com.vn/search?q=" + " " + textBox2.Text + " " + "site: " + textBox3.Text);
        //        }
        //    }
        //}
        RegistryKey rk = Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Run", true);

        private void SetStartup()
        {
                rk.SetValue("WindowsFormsApplication1.exe", Application.ExecutablePath.ToString());
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
           

        }



        private void radioButton15_CheckedChanged(object sender, EventArgs e)
        {
            
                Process.Start("https://www.facebook.com/");
 
        }

        private void radioButton14_CheckedChanged(object sender, EventArgs e)
        {
            
                Process.Start("https://plus.google.com");

        }

        private void radioButton12_CheckedChanged(object sender, EventArgs e)
        {
           
                Process.Start("https://twitter.com/twister");

        }
       
        private void radioButton10_CheckedChanged(object sender, EventArgs e)
        {
            
                Process.Start("http://en.nhandan.org.vn/society/item/1592402-.html");
     
        }

        private void radioButton19_CheckedChanged(object sender, EventArgs e)
        {
           
                Process.Start("http://e.vnexpress.net/");

        }

        private void radioButton18_CheckedChanged(object sender, EventArgs e)
        {
           
                Process.Start("http://www.dtinews.vn/");
   
        }

        private void radioButton17_CheckedChanged(object sender, EventArgs e)
        {
           
                Process.Start("http://www.vtc.vn/");
             
        }

        private void radioButton22_CheckedChanged(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage1;
        }

        private void radioButton21_CheckedChanged(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage2;
        }

        private void label4_Click(object sender, EventArgs e)
        {
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label4.Text = "Bây Giờ Là: " + DateTime.Now.ToLongTimeString();
        }

        private void radioButton20_CheckedChanged(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage4;
        }

        private void radioButton23_CheckedChanged(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = tabPage5;
        }

        private void radioButton27_CheckedChanged(object sender, EventArgs e)
        {
            if (textBox5.Text == "" && radioButton27.Checked == true)
            {
                MessageBox.Show("BẠN VUI LÒNG NHẬP THÔNG TIN CẦN TÌM Ở ĐÂY", "THÔNG BÁO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox5.Focus();
                textBox5.Text = "";
                radioButton27.Checked = false;
            }
            if (textBox5.Text != "" && radioButton27.Checked == true)
            {
                Process.Start("https://www.google.com.vn/search?q=" + textBox5.Text);
            }
        }

        private void radioButton26_CheckedChanged(object sender, EventArgs e)
        {
            if (textBox5.Text == "" && radioButton26.Checked == true)
            {
                MessageBox.Show("BẠN VUI LÒNG NHẬP THÔNG TIN CẦN TÌM Ở ĐÂY", "THÔNG BÁO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox5.Focus();
                textBox5.Text = "";
                radioButton26.Checked = false;
            }
            if (textBox5.Text != "" && radioButton26.Checked == true)
            {
                Process.Start("https://vn.search.yahoo.com/search?p=    " + textBox5.Text);
            }
        }

        private void radioButton25_CheckedChanged(object sender, EventArgs e)
        {
            if (textBox5.Text == "" && radioButton25.Checked == true)
            {
                MessageBox.Show("BẠN VUI LÒNG NHẬP THÔNG TIN CẦN TÌM Ở ĐÂY", "THÔNG BÁO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox5.Focus();
                textBox5.Text = "";
                radioButton25.Checked = false;
            }
            if (textBox5.Text != "" && radioButton25.Checked == true)
            {
                Process.Start("http://www.bing.com/search?q=" + textBox5.Text);
            }
        }

        private void radioButton24_CheckedChanged(object sender, EventArgs e)
        {
            if (textBox5.Text == "" && radioButton24.Checked == true)
            {
                MessageBox.Show("BẠN VUI LÒNG NHẬP THÔNG TIN CẦN TÌM Ở ĐÂY", "THÔNG BÁO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox5.Focus();
                textBox5.Text = "";
                radioButton24.Checked = false;
            }
            if (textBox5.Text != "" && radioButton24.Checked == true)
            {
                Process.Start("http://coccoc.com/search#query=" + textBox5.Text);
            }
        }

        private void tabPage4_Click(object sender, EventArgs e)
        {
            textBox5.Focus();
        }

        private void textBox6_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
                e.Handled = true;
        }

        private void radioButton31_CheckedChanged(object sender, EventArgs e)
        {
            if (textBox6.Text == "" && radioButton31.Checked == true)
            {
                MessageBox.Show("BẠN VUI LÒNG NHẬP SỐ ĐIỆN THOẠI NGƯỜI CẦN TÌM Ở ĐÂY", "THÔNG BÁO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox6.Focus();
                textBox6.Text = "";
                radioButton24.Checked = false;
            }
            if (textBox6.Text != "" && radioButton31.Checked == true)
            {
                Process.Start("https://www.google.com.vn/search?q=" + textBox6.Text);
            }
        }

        private void radioButton28_CheckedChanged(object sender, EventArgs e)
        {
            if (textBox6.Text == "" && radioButton28.Checked == true)
            {
                MessageBox.Show("BẠN VUI LÒNG NHẬP SỐ ĐIỆN THOẠI NGƯỜI CẦN TÌM Ở ĐÂY", "THÔNG BÁO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox6.Focus();
                textBox6.Text = "";
                radioButton24.Checked = false;
            }
            if (textBox6.Text != "" && radioButton28.Checked == true)
            {
                Process.Start("https://www.facebook.com/search/top/?q=" + textBox6.Text);
            }
        }
    }
}
